# Папка для векторных иконок, которые станут спрайтом в `build/images/icons/stack.svg`.
